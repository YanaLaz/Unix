import unittest
import socket
import log
import logging
import sys
from sock.auth import auth

logger = logging.getLogger()
stream_handler = logging.StreamHandler(sys.stdout)
logger.addHandler(stream_handler)


class TestCase(unittest.TestCase):
    """Тесты для FTP сервера"""

    def setUp(self) -> None:
        self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.client.connect(('localhost', 9002))

    def tearDown(self) -> None:
        self.client.close()

    def test_pwd(self):
        auth_result = auth('test', '123')  # авторизация пользователя для теста
        command = f'{auth_result}: pwd'.encode()
        self.client.send(command)
        logger.info(command)
        self.assertEqual(self.client.recv(1024).decode().split('/')[5],
                         'filemanager')

        command = f'{auth_result}: create -d test_package'.encode()
        self.client.send(command)
        logger.info(command)
        self.assertEqual(self.client.recv(1024).decode().split('-')[1].strip(), 'создан')

        command = f'{auth_result}: move in test_package'.encode()
        self.client.send(command)
        logger.info(command)
        self.assertEqual(self.client.recv(1024).decode().split('/')[-1], 'test_package')

        command = f'{auth_result}: move up'.encode()
        self.client.send(command)
        logger.info(command)
        self.assertTrue(self.client.recv(1024).decode())

        command = f'{auth_result}: remove -d test_package'.encode()
        self.client.send(command)
        logger.info(command)
        self.assertEqual(self.client.recv(1024).decode().split(' ')[2], 'удалена')

        command = f'{auth_result}: create -f test.txt'.encode()
        self.client.send(command)
        logger.info(command)
        self.assertEqual(self.client.recv(1024).decode().split(' ')[1], 'создан')

        command = f'{auth_result}: write -f test.txt hello'.encode()
        self.client.send(command)
        logger.info(command)
        self.assertEqual(self.client.recv(1024).decode(), 'в файл test.txt записан текст')

        command = f'{auth_result}: read -f test.txt'.encode()
        self.client.send(command)
        logger.info(command)
        self.assertEqual(self.client.recv(1024).decode(), 'hello')

        command = f'{auth_result}: remove -f test.txt'.encode()
        self.client.send(command)
        logger.info(command)
        self.assertEqual(self.client.recv(1024).decode().split(' ')[2], 'удален')




if __name__ == '__name__':
    unittest.main()
