import socket
import threading
import log
import logging
from app import manager
from fmanager import FileManager

logger = logging.getLogger('__name__')  # подключаем логирование
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)  # отключаем ожидание
server.bind(('localhost', 9002))
server.listen(10)
logger.info('server is running')  # информируем, что сервер запущен


def accept():
    while True:
        try:
            file_manager = FileManager()  # инциализируем класс менеджер
            conn, addr = server.accept()
            logger.info(addr)
            threading.Thread(target=connect, args=[conn, addr, file_manager]).start()
        except Exception as ex:
            logger.exception(ex)


def connect(conn, addr, file_manager):
    print('connect: ', file_manager.get_pathway())
    while True:
        try:
            recv = conn.recv(1024).decode()
            client_path = recv.split(':')[0]  # сплитим сообщение, получаем путь к папке
            client_message = recv.split(':')[1].strip()  # сплитим сообщение, получаем команду, которую надо выполнить
            if recv:
                logger.info(f'{addr}: {recv}')
                print(file_manager.get_pathway())
                answer = manager(client_message, client_path,
                                 file_manager)  # передаем в менеджер команду, путь к папке и класс Filemanager
                conn.send(answer.encode())
            else:
                conn.close()
                logger.warning(f'{addr} отключился')
                break
        except Exception as ex:
            logger.exception(ex)
            conn.close()
            break


t = threading.Thread(target=accept).start()
