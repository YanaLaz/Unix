import os
import shutil


def download(from_f, to_f):
    shutil.copy2(fr'{from_f}', fr'{to_f}')